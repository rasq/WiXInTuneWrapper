Thanks for contributing!

Please be sure you are following the guidelines at 
https://github.com/FaisalUmair/udemy-downloader-gui/blob/master/CONTRIBUTING.md
